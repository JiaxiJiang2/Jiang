import * as d3 from "https://cdn.jsdelivr.net/npm/d3@7/+esm";

// Load Data
const csvFile = "data/world_data_v3.csv";
const jsonFile = "data/world_data.json";

let currentAttribute = "electricity_consumption_per_capita";

// Initialize D3 and Leaflet
document.addEventListener("DOMContentLoaded", () => {
    d3.csv(csvFile).then(data => {
        createBarCharts(data);
        createMap(data);
        setupInteractivity(data);
    });

    document.getElementById("attributeSelect").addEventListener("change", (event) => {
        currentAttribute = event.target.value;
        d3.csv(csvFile).then(data => updateCharts(data));
    });
});

// Create Bar Charts
function createBarCharts(data) {
    const chart1 = d3.select("#chart1");
    const chart2 = d3.select("#chart2");

    updateCharts(data, chart1, chart2);
}

function updateCharts(data) {
    const chart1 = d3.select("#chart1");
    const chart2 = d3.select("#chart2");

    // Clear previous charts
    chart1.selectAll("*").remove();
    chart2.selectAll("*").remove();

    // Scale and Axis
    const xScale = d3.scaleBand()
        .domain(data.map(d => d.country))
        .range([0, 800])
        .padding(0.2);

    const yScale = d3.scaleLinear()
        .domain([0, d3.max(data, d => +d[currentAttribute])])
        .range([300, 0]);

    // Add Bars
    chart1.selectAll("rect")
        .data(data)
        .enter()
        .append("rect")
        .attr("x", d => xScale(d.country))
        .attr("y", d => yScale(d[currentAttribute]))
        .attr("width", xScale.bandwidth())
        .attr("height", d => 300 - yScale(d[currentAttribute]))
        .attr("fill", "steelblue");

    chart2.selectAll("rect")
        .data(data)
        .enter()
        .append("rect")
        .attr("x", d => xScale(d.country))
        .attr("y", d => yScale(d[currentAttribute]))
        .attr("width", xScale.bandwidth())
        .attr("height", d => 300 - yScale(d[currentAttribute]))
        .attr("fill", "orange");
}

// Create Map with Leaflet
function createMap(data) {
    const map = L.map('map').setView([20, 0], 2);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors'
    }).addTo(map);

    data.forEach(country => {
        const lat = +country.latitude;
        const lon = +country.longitude;

        const marker = L.marker([lat, lon]).addTo(map);
        marker.bindPopup(`<b>${country.country}</b><br>${currentAttribute}: ${country[currentAttribute]}`);
    });
}

// Setup Interactivity
function setupInteractivity(data) {
    // Implement synchronization between charts and map
    // Add highlighting logic
}
